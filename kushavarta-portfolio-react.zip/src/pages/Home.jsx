import React from 'react';

const Home = () => (
  <div className='p-10 text-center'>
    <h1 className='text-4xl font-bold'>Hi, I'm Kushavarta Nagnath Aglave</h1>
    <p className='mt-4'>Data Analyst | Python | SQL | Power BI | Excel</p>
  </div>
);

export default Home;