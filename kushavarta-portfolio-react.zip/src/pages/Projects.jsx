import React from 'react';

const Projects = () => (
  <div className='p-10'>
    <h2 className='text-3xl font-bold'>Projects</h2>
    <ul className='list-disc ml-6 mt-4'>
      <li>Book Recommender System</li>
      <li>Employee Analysis</li>
      <li>Diabetic Patients Analysis and Predictive Model</li>
      <li>E-commerce Sales Dashboard</li>
      <li>Healthcare Stroke Dashboard</li>
    </ul>
  </div>
);

export default Projects;