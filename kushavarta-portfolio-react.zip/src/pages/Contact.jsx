import React from 'react';

const Contact = () => (
  <div className='p-10'>
    <h2 className='text-3xl font-bold'>Contact Me</h2>
    <p className='mt-4'>Email: your-email@example.com</p>
    <p>LinkedIn: linkedin.com/in/kushavarta</p>
    <p>GitHub: github.com/kushavarta</p>
  </div>
);

export default Contact;