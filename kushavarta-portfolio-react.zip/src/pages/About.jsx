import React from 'react';

const About = () => (
  <div className='p-10'>
    <h2 className='text-3xl font-bold'>About Me</h2>
    <p className='mt-4'>Data Analyst with expertise in Python, SQL, Power BI, Excel, and basic ML. Strong communication and team collaboration skills.</p>
  </div>
);

export default About;